export class ResponseLogin {
  public jwt: string;
}
