export class RequestLogin {
  public email: string;
  public password: string;
}
